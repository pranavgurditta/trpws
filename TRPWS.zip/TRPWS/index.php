<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

  <title>The Rising People Welfare Society</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  
<style>
.ww
{
height:145px;
}
p
{
font-size:22px;
}
.ww2
{
height:145px;
}

.fa {
  padding: 20px;
  font-size: 30px;
  width: 40px;
  text-align: center;
  text-decoration: none;
  margin: 5px 2px;
  border-radius: 50%;
}

.fa:hover {
    opacity: 0.7;
}
.d5
{
width:100%;
height:800px;
} 
.fa-facebook {
  background: #3B5998;
  color: white;
}

.fa-twitter {
  background: #55ACEE;
  color: white;
}

.fa-google {
  background: #dd4b39;
  color: white;
}

.fa-linkedin {
  background: #007bb5;
  color: white;
}
p
{
font-size:15px;
}

h2{
color:white;
 background: #43a286;
line-height: 0.9em;
}
.g
{
background:#0d6565;
margin-top: 10px;
}

.fa-youtube {
  background: #bb0000;
  color: white;
}

.fa-instagram {
  background: #125688;
  color: white;
}



    /* Remove the navbar's default margin-bottom and rounded borders */ 
.navbar-default {
text-align: center;
border: 0;
color:white;background: #43a286;

}
a
{
color:white;
}
.p2
{
font-size:60px;
color:white;
height:auto;
}


ul
{
color:white;
 background: #43a286;

}
.navbar-default .navbar-brand {
color:white;
 background: #43a286;
   
}
    .navbar {
      margin-bottom: 0;
      border-radius: 0;
      
    }
.thumbnail
{
height:500px;
}
.d2 img
{
height:400px;
width:100%
}

.thumbnail img
{
height:300px;
}

.navbar-default .navbar-nav>li>a {
    color:white;  
}

.container
{
border:10px;
 padding:25px;
width:100%;
}
.img-rounded
{
 padding: 5px;
}
body
{
padding-top:0px;
 background-color:#ffffff;
color:black;
}
head
{
color:white;
 background: #43a286;


}


container-fluid
{
color:white;
 background: #43a286;
}
       
    /* Add a gray background color and some padding to the footer */
    footer {
      background-color: #ffffff;
      padding: 5px;
    }
     .carousel-inner img {
      width: 100%; /* Set width to 100% */
      margin: auto;
height:auto;
      min-height:150px;
max-height:450px;

  }
.d
{
width:100%;
 height:500px;
}

  /* Hide the carousel text when the screen is less than 600 pixels wide */
  @media (max-width: 600px) {
    .carousel-caption {
      display: none; 
    }
.item{
 height:215px;
}
.d5
{
height:100%;
}
 
    .carousel-inner img {
      width: 100%; /* Set width to 100% */
      margin: auto;
height:400px;

  }
.ww
{
height:410px;
}
.ww2
{
height:435px;
}

  

.d2 img
{
height:350px;
width:100%
}
.d
{
width:100%;
 height:350px;
}
.d5
{
width:100%;
 height:350px;
}
}
header{
      
background:#00795f;
      width: 100%;
      padding: 30px 0;
      color: white;
text-align: center;
}


  </style>
</head>
<body>
<header><h1>THE RISING PEOPLE WELFARE SOCIETY</h1></header>
<nav class="navbar navbar-default style="color:white,background: #43a286"">
  <div class="container-fluid" style="color:white,background: #43a286">
    <div class="navbar-header" style="color:white,background: #43a286">
<a class="navbar-brand" href="#"></a> 
 <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">  
  
<span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>   
      </button>
                     
    
     </div>
    <div class="collapse navbar-collapse" id="myNavbar" style="color:white,background: #43a286">
      <ul class="nav navbar-nav navbar-right" style="color:white,background: #43a286">
        <li><a style="color:white,background: #43a286" href="#">HOME</a></li>
        <li><a style="color:white,background: #43a286"href="aus.php">ABOUT US</a></li>
        <li><a style="color:white,background: #43a286" href="intern.php">INTERN</a></li>
        <li><a style="color:white,background: #43a286" href="thumbnail.php">GALLERY</a></li>
        <li><a style="color:white,background: #43a286" href="contact/x.php">CONTACT US</a></li>
      
</ul>

    </div>
  </div>
</nav>


<div id="myCarousel" class="carousel slide" data-ride="carousel" style="height:50%">
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>

      <li data-target="#myCarousel" data-slide-to="3"></li>


    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner" role="listbox">
      <div class="item active">
        <img src="45.jpg" alt="Image">
        <div class="carousel-caption">
          <h3>Love</h3>
          <p>to study</p>
        </div>      
      </div>
 <div class="item">
        <img src="fwdre/education.jpg" alt="Image">
        <div class="carousel-caption">
          <h3>Love</h3>
          <p>to study</p>
        </div>      
      </div>
      <div class="item">
        <img src="ab.jpg" alt="Image">
        <div class="carousel-caption">
          <h3></h3>
          <p></p>
        </div>      
      </div>
      <div class="item">
        <img src="yes1.png" alt="Image">
        <div class="carousel-caption">
          <h3>Draw</h3>
          <p>the rainbows of thoughts via study</p>
        </div>      
      </div>
    </div>

    <!-- Left and right controls -->
    <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
</div>

<!-- /.container 

<div class="container">
<center><h2> OUR WORK </h2></center>
<img src="1b.png" style="width:100%">
</div>

<center>
<div class="container">
<img src="w.jpeg" >
</div></center>

-->
<br>
<div class="container-fluid">
  <div class="row" style="background:black;color:white;font-family: Times New Roman, Helvetica, sans-serif;padding:bottom:40px;margin-bottom:20px;">
   <center> <div class="col-sm-4 col-md-4 col-lg-4 col-xs-12" style="background-color:black;padding:bottom:1%;">
<h1>WHO WE ARE AND WHAT DO WE DO?</h1>
</div></center>
    <div class="ww col-sm-8 col-md-8 col-lg-8 col-xs-12" style="background-color:#00795f;color:black;text-align:left;">
<h2 style="background:#00795f;color:black;">
The Rising People Welfare Society aims to build a better living ecosystem to the underprivileged children in New Delhi by providing them with the right education and care at the right time in life.</h2></div>
  </div>
  </div>
  
<div class="container-fluid">
  <div class="row" style="background:black;color:white;font-family:  Times New Roman, Helvetica, sans-serif;padding:bottom:40px;margin-bottom:20px;">
   <center> <div class="col-sm-4 col-md-4 col-lg-4 col-xs-12" style="background-color:black;padding:bottom:1%;">
<h1>WE TEACH THEM THE RIGHT WAY</h1>
</div></center>
    <div class="ww2 col-sm-8 col-md-8 col-lg-8 col-xs-12" style="background-color:#00795f;color:black;text-align:left;">
<h2 style="background:#00795f;color:black;">TRPWS is a joint programme with the mission to empower and support underprivileged children by ensuring that every child has at least 1 adult assigned to them.</h2></div>
  </div>
  </div>
 <!--
<div class="container-fluid">
  <div class="row" style="background-color:yellow;">
<center><h4>We take them to the right way by providing them with:</h4>
<h3>
<center>
<p align="center"><font size=5><B>1. The Right Education</font></B><BR><BR></font></p>

<p align="center"><font size=5><B>2. The Right Experience</font></B><BR><BR></font></p>

<p align="center"><font size=5><B>3. The Right Guidance</font></B><BR><BR></font></p>

<p align="center"><font size=5><B>4. The Right Care</font></B><BR><BR></font></p>
</center>
</h3>
</center>
  </div>
  </div>
    <center>
-->
<center>
<div class="g" >             
  <img src="7 (2).jpg" class="img-responsive d5"  alt="what we do ">      
</div>
</center>

<div class="container" >
<center><h2>SERVICES WE PROVIDE</h2></center>
	<div class="flex-row row">


		<div class="col-xs-6 col-sm-4 col-lg-4">
			<div class="thumbnail " style="background-color:#6dc756">
								<img  src="i.jpg" class="w3-circle" style="width:100%">
				<div class="caption" style="color:white">
					<u><h3>  Teaching   </h3></u>
<p class="flex-text text-muted" style="color:white; text-align:justify">
                        In todays world, everyone needs to be educated. To survive in this world, mere literacy isn't enough. Our kids are taught alphabets to alpha beta gama. We make sure that at the end of the day, the child doesn't only have fun but learn something of value.

</p>
					<p>
					
					</p>
				</div>
				<!-- /.caption -->
			</div>
			<!-- /.thumbnail -->
		</div>



		<div class="col-xs-6 col-sm-4 col-lg-4 ">
			<div class="thumbnail "style="background-color:#009c7f">
								<img src="ii.jpg" class="w3-circle">
				<div class="caption" style="color:white">
					<u><h3>Donation drives</h3></u>
					<p class="flex-text text-muted"  style="color:white; text-align:justify">
One man's trash is another man's treasure. Our needy children get donations every month from the privileged section. You never know, a pen to you, is worth a career to another.
</p>
					<p>&nbsp
					</p>

				</div>
				<!-- /.caption -->
			</div>
			<!-- /.thumbnail -->
		</div>



		<div class="col-xs-6 col-sm-4 col-lg-4">
			<div class="thumbnail " style="background-color:#7686b1">
							<img src="iii.jpg" style="width:100%" class="w3-circle">
				<div class="caption" style="color:white">
				<u>	<h3>Ending drug menace</h3></u>
					<p class="flex-text text-muted" style="color:white; text-align:justify">
We believe that drugs and addictions are a pediment in a child's future. Our attempts to divert children from the wrong path and get rid of any addictions have been successful so far.<br>


</p>
					<p>&nbsp	
					</p>
				</div>
				<!-- /.caption -->
			</div>
			<!-- /.thumbnail -->
		</div>



	</div>
	<!-- /.flex-row  -->
</div>
<!--
<center>
<div class="container">                 
  <img src="m.jpg" class="img-responsive" style="width:80%, height:800px" alt="what we do "> 
</div>
</center>
-->

<div class="container">
<center><h2>EDUCATION @ TRPWS </h2></center>
	<div class="flex-row row">





		<div class="col-xs-6 col-sm-4 col-lg-4">
			<div class="d2" style="margin-bottom:5px">
								<img  src="fwdre/education.jpg">
		
<center><h3   style="background:#43a286;color:white;" >                                WE LOVE     </h3>		</center>
			</div>
			<!-- /.thumbnail -->
		</div>



		<div class="col-xs-6 col-sm-4 col-lg-4 ">
			<div class="d2" style="margin-bottom:5px">
								<img src="poster3.jpg" style="width:100%">
			

<center><h3                   style="background:#43a286;color:white" >           WE CARE   </h3>		</center>
			</div>
			<!-- /.thumbnail -->
		</div>


		<div class="col-xs-6 col-sm-4 col-lg-4">
			<div class="d2" style="margin-bottom:5px">
								<img src="fwdre/poster4.jpg">
	
<center><h3 style="background:#43a286;color:white">              WE TEACH     </h3>		</center>
			</div>
			<!-- /.thumbnail -->
		</div>


	</div>
	<!-- /.flex-row  -->
</div>
<div class="container">
<center><h2>CONNECT WITH TRPWS</h2></center>
	<div class="flex-row row">





		<div class="col-xs-6 col-sm-4 col-lg-4">
			<div class="thumbnail">
								<img  src="mission.jpg">
				<div class="caption">
					<h3>About us:                                                          </h3>
<p class="flex-text text-muted">
Life is a learning experience. We hope you would be glad to know about us and our work for the society.
</p>
					<p>
						<a class="btn btn-primary" href="aboutus.php">Read more</a>
					</p>
				</div>
				<!-- /.caption -->
			</div>
			<!-- /.thumbnail -->
		</div>



		<div class="col-xs-6 col-sm-4 col-lg-4 ">
			<div class="thumbnail ">
								<img src="2.jpeg" style="width:100%">
				<div class="caption">
					<h3>Internships:</h2>
					<p class="flex-text text-muted">
Learn by exploring yourself more and dive into our world with the wide amount of opportunities we give you to serve the society.
</p>
					<p>
						<a class="btn btn-primary" href="intern.php">Read more</a>
					</p>
				</div>
				<!-- /.caption -->
			</div>
			<!-- /.thumbnail -->
		</div>


		<div class="col-xs-6 col-sm-4 col-lg-4">
			<div class="thumbnail ">
								<img src="contact.jpg">
				<div class="caption">
					<h3>Contact us:</h2>
					<p class="flex-text text-muted">
We would love to hear from you. We would get in touch with you as soon as possible.
</p>
					<p>
						<a class="btn btn-primary" href="contact/x.php">Read more</a>
					</p>
				</div>
				<!-- /.caption -->
			</div>
			<!-- /.thumbnail -->
		</div>


	</div>
	<!-- /.flex-row  -->
</div>
</div>
<!--
<center>
<div class="container">                 
  <img src="e.png" class="img-responsive d"  alt="what we do "> 
</div>
</center>
-->

<footer>
	
<?php
require('footer.php');
?>
</footer>



<!-- DEMO STYLES and NOTES BELOW -->
<style type="text/css">
body {
		background-color: rgba(0, 0, 0, 0.03);
		font-family: 'Lato', sans-serif;
	}

/* make gutter sizes consistent */
.flex-row  {
    padding-left: 15px;
    padding-right: 15px;
}

/* 
  Extra Small Devices, Phones { .col-xs-$ } 
    ~ 480px to 767px ~

  Extra Small Devices, Phones { .col-sm-$ } 
    ~ 768px to 991px ~

  Extra Small Devices, Phones { .col-md-$ } 
    ~ 992 to 1200px ~

  Extra Small Devices, Phones { .col-lg-$ } 
    ~ 1201px up ~
 */

/* Extra Media Query Below for Retina Iphones and Smaller */
@media only screen and (max-width : 480px){
	.flex-row > [class*='col-'] {
			width: 100%;
	}
	.flex-row  {
    padding-left: 0px;
    padding-right: 0px;
  }
}
</style>


</html>