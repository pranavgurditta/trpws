<!DOCTYPE html>
<html lang="en">
<head>
  <title>The Rising People Welfare Society</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  
<style>

.fa {
  padding: 20px;
  font-size: 30px;
  width: 40px;
  text-align: center;
  text-decoration: none;
  margin: 5px 2px;
  border-radius: 50%;
}

.fa:hover {
    opacity: 0.7;
}

.fa-facebook {
  background: #3B5998;
  color: white;
}

.fa-twitter {
  background: #55ACEE;
  color: white;
}

.fa-google {
  background: #dd4b39;
  color: white;
}

.fa-linkedin {
  background: #007bb5;
  color: white;
}
h2{
color:blue;
}

.fa-youtube {
  background: #bb0000;
  color: white;
}

.fa-instagram {
  background: #125688;
  color: white;
}



    /* Remove the navbar's default margin-bottom and rounded borders */ 
.navbar-default {
text-align: center;
border: 0;
color:white;background: #43a286;

}
a
{
color:white;
}

ul
{
color:white;
 background: #43a286;

}
.navbar-default .navbar-brand {
color:white;
 background: #43a286;
   
}
    .navbar {
      margin-bottom: 0;
      border-radius: 0;
      
    }

.thumbnail img
{
height:300px;
}
.navbar-default .navbar-nav>li>a {
    color:white;  
}

.container
{
border:10px;
 padding:25px;
width:100%;
}
.img-rounded
{
 padding: 5px;
}
body
{
padding-top:0px;background: #43a286;
color:black;
}

head
{
color:white;
 background: #43a286;


}


container-fluid
{
color:white;
 background: #43a286;
}
       
    /* Add a gray background color and some padding to the footer */
    footer {
      background-color: #ffffff;
      padding: 5px;
    }
    
  .carousel-inner img {
      width: 100%; /* Set width to 100% */
      margin: auto;
height:auto;
      min-height:150px;
max-height:450px;

  }

  /* Hide the carousel text when the screen is less than 600 pixels wide */
  @media (max-width: 600px) {
    .carousel-caption {
      display: none; 
    }
  }

header{
      
background: #00795f;
      width: 100%;
      padding: 30px 0;
      color: white;
text-align: center;
}


  </style>
</head>
<body style="background-color:#43a286">


<header><h1>THE RISING PEOPLE WELFARE SOCIETY</h1></header>
<nav class="navbar navbar-default style="color:white,background: #43a286"">
  <div class="container-fluid" style="color:white,background: #43a286">
    <div class="navbar-header" style="color:white,background: #43a286">
<a class="navbar-brand" href="#"></a> 
 <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">  
  
<span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>   
      </button>
                     
    
     </div>
    <div class="collapse navbar-collapse" id="myNavbar" style="color:white,background: #43a286">
      <ul class="nav navbar-nav navbar-right" style="color:white,background: #43a286">
        <li><a style="color:white,background: #43a286" href="#">HOME</a></li>
        <li><a style="color:white,background: #43a286"href="aboutus.php">ABOUT US</a></li>
        <li><a style="color:white,background: #43a286" href="intern.php">INTERN</a></li>
        <li><a style="color:white,background: #43a286" href="thumbnail.php">GALLERY</a></li>
<li><a href="https://trpws2015.wordpress.com/" style="color:white,background: #43a286">BLOG</a></li>
        <li><a style="color:white,background: #43a286" href="contact/x.php">CONTACT US</a></li>
      
</ul>

    </div>
  </div>
</nav>


<div id="myCarousel" class="carousel slide" data-ride="carousel" style="height:50%">
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>


    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner" role="listbox">
      <div class="item active" >
<script  src="https://infograph.venngage.com/js/embed/v1/embed.js" data-vg-id="284647" data-title="Creative Process" ></script>
        <div class="carousel-caption">
          <h3>Love</h3>
          <p>to study</p>
        </div>      
      </div>

      <div class="item">
        <img src="45.jpg" alt="Image">
        <div class="carousel-caption">
          <h3>We believe in</h3>
          <p>Educating</p>
        </div>      
      </div>
      <div class="item">
        <img src="9.jpg" alt="Image">
        <div class="carousel-caption">
          <h3>Draw</h3>
          <p>the rainbows of thoughts via study</p>
        </div>      
      </div>
    </div>

    <!-- Left and right controls -->
    <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
</div>

<!-- /.container 

<div class="container">
<center><h2> OUR WORK </h2></center>
<img src="1b.png" style="width:100%">
</div>
 -->

<div style="width:100% background-color:"#43a286" >

</div>

<div background-color:"#43a286">
<center><img src="1a.png" style="align:middle">
</center></div>
<div class="container">
<center><h2>CONNECT WITH TRPWS</h2></center>
	<div class="flex-row row">





		<div class="col-xs-6 col-sm-4 col-lg-4">
			<div class="thumbnail">
								<img  src="mission.jpg">
				<div class="caption">
					<h3>About us:                                                          </h3>
<p class="flex-text text-muted">
Life is a learning experience.  
</p>
					<p>
						<a class="btn btn-primary" href="https://trpws2015.wordpress.com/about/">Read more</a>
					</p>
				</div>
				<!-- /.caption -->
			</div>
			<!-- /.thumbnail -->
		</div>



		<div class="col-xs-6 col-sm-4 col-lg-4 ">
			<div class="thumbnail ">
								<img src="2.jpeg">
				<div class="caption">
					<h3>Internships:</h2>
					<p class="flex-text text-muted">
Learn by exploring yourself more  
</p>
					<p>
						<a class="btn btn-primary" href="intern.php">Read more</a>
					</p>
				</div>
				<!-- /.caption -->
			</div>
			<!-- /.thumbnail -->
		</div>


		<div class="col-xs-6 col-sm-4 col-lg-4">
			<div class="thumbnail ">
								<img src="contact.jpg">
				<div class="caption">
					<h3>Contact us:</h2>
					<p class="flex-text text-muted">
We would love to hear from you.
</p>
					<p>
						<a class="btn btn-primary" href="contact/x.php">Read more</a>
					</p>
				</div>
				<!-- /.caption -->
			</div>
			<!-- /.thumbnail -->
		</div>


	</div>
	<!-- /.flex-row  -->
</div>


<footer>
	
<?php
require('footer.php');
?>
</footer>



<!-- DEMO STYLES and NOTES BELOW -->
<style type="text/css">
body {
		background-color: rgba(0, 0, 0, 0.03);
		font-family: 'Lato', sans-serif;
	}

/* make gutter sizes consistent */
.flex-row  {
    padding-left: 15px;
    padding-right: 15px;
}

/* 
  Extra Small Devices, Phones { .col-xs-$ } 
    ~ 480px to 767px ~

  Extra Small Devices, Phones { .col-sm-$ } 
    ~ 768px to 991px ~

  Extra Small Devices, Phones { .col-md-$ } 
    ~ 992 to 1200px ~

  Extra Small Devices, Phones { .col-lg-$ } 
    ~ 1201px up ~
 */

/* Extra Media Query Below for Retina Iphones and Smaller */
@media only screen and (max-width : 480px){
	.flex-row > [class*='col-'] {
			width: 100%;
	}
	.flex-row  {
    padding-left: 0px;
    padding-right: 0px;
  }
}
</style>


</html>