<HEAD>
<SCRIPT language="JavaScript">
<!--hide

var password;
var pass1="jaimatadi";

password=prompt('Please enter your password to view this page!',' ');

if (password==pass1)
{
  alert('Password Correct! Click OK to enter!');
window.location="contact/a2.csv";
}
else
   {
    window.location="index.php";
    }

//-->
</SCRIPT>
</HEAD>
<body>

</html>