<html>
<head>
 <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  
<style>
    /* Remove the navbar's default margin-bottom and rounded borders */ 
.navbar-default {background:#43a286;
text-align: center;
border: 0;


}

ul
{
color:black;

}
.navbar-default .navbar-brand {
    color:black;
}
    .navbar {
      margin-bottom: 0;
      border-radius: 0;
    }

.thumbnail img
{
height:300px;
}

.container
{
border:10px;
 padding:25px;
}
.img-rounded
{
 padding: 5px;
}
body
{
padding-top:0px;
 background-color:#ffffff;
color:black;
}
head
{
color:black;
 background-color:#ffffff;
}
       
    /* Add a gray background color and some padding to the footer */
    footer {
      background-color: #ffffff;
      padding: 5px;
    }
    
  .carousel-inner img {
      width: 100%; /* Set width to 100% */
      margin: auto;
height:auto;
      min-height:150px;
max-height:450px;

  }

  /* Hide the carousel text when the screen is less than 600 pixels wide */
  @media (max-width: 600px) {
    .carousel-caption {
      display: none; 
    }
  }

header{
      
background: #00795f;
      width: 100%;
      padding: 30px 0;
      color: white;

     text-align: center;
}

.navbar-default .navbar-nav>li>a {
    color:white;
background:#43a286;
 
}
  </style>
</head>
<body>

<header><h1>THE RISING PEOPLE WELFARE SOCIETY</h1></header>
 
<nav class="navbar navbar-default ">
  <div class="container-fluid">
    <div class="navbar-header">
<a class="navbar-brand" href="#"></a> 
 <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">  
  
<span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>   
      </button>
                     
    
     </div>
    <div class="collapse navbar-collapse" id="myNavbar" style="color:black">
      <ul class="nav navbar-nav navbar-right" style="color:black">
        <li><a href="index.php">HOME</a></li>
        <li><a href="aus.php">ABOUT US</a></li>
        <li><a href="intern.php">INTERN</a></li>
        <li><a href="thumbnail.php">GALLERY</a></li>        
<li><a href="contact/x.php">CONTACT US</a></li>
        

 
      </ul>
    </div>
  </div>
</nav>

</body>
</html>