<html>
<head>
<style>
@import url(https://fonts.googleapis.com/css?family=Lato);
@import url(https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.css);
footer {
    font-family: Times New Roman, sans-serif;
    color: #FFF;

    -webkit-font-smoothing: antialiased;
}
.s{
      
background: #00795f;

}
a {
    text-decoration: none;
    color: #fff;
}
p > a:hover{
    color: #d9d9d9;
    text-decoration:  underline;
}
h1,
h2,
h3,
h4,
h5,
h6 {
    margin:  1% 0 1% 0;
}
._12 {
    font-size: 1.8em;
}
._14 {
    font-size: 2.0em;
}
ul {
    padding:0;
    list-style: none;
}
.footer-social-icons {
    width: 300px;

background: #00795f;
    display:block;
    margin: 0 auto;
}
.social-icon {
    color: #fff;
background: #00795f;

}
ul.social-icons {
    margin-top: 10px;
background: #00795f;}
.social-icons li {
    vertical-align: top;
    display: inline;
    height: 100px;
}
.social-icons a {
    color: #fff;
    text-decoration: none;
}
.fa-facebook {
    padding:10px 14px;
    -o-transition:.5s;
    -ms-transition:.5s;
    -moz-transition:.5s;
    -webkit-transition:.5s;
    transition: .5s;
    background-color: #3d5b99;
}
.fa-facebook:hover {
    background-color: #3d5b99;
}
.fa-twitter {
    padding:10px 12px;
    -o-transition:.5s;
    -ms-transition:.5s;
    -moz-transition:.5s;
    -webkit-transition:.5s;
    transition: .5s;
    background-color: #00aced;
}
.fa-twitter:hover {
    background-color: #00aced;
}
.fa-instagram {
    padding:10px 14px;
    -o-transition:.5s;
    -ms-transition:.5s;
    -moz-transition:.5s;
    -webkit-transition:.5s;
    transition: .5s;
    background-color: #fb3958;
}
.fa-instagram:hover {
    background-color: #fb3958;
}
.fa-youtube {
    padding:10px 14px;
    -o-transition:.5s;
    -ms-transition:.5s;
    -moz-transition:.5s;
    -webkit-transition:.5s;
    transition: .5s;
   background-color: #e64a41;
}
.fa-youtube:hover {
    background-color: #e64a41;
}
.fa-linkedin {
    padding:10px 14px;
    -o-transition:.5s;
    -ms-transition:.5s;
    -moz-transition:.5s;
    -webkit-transition:.5s;
    transition: .5s;
    background-color: #0073a4;
}
.fa-linkedin:hover {
    background-color: #0073a4;
}
.fa-google-plus {
    padding:10px 9px;
    -o-transition:.5s;
    -ms-transition:.5s;
    -moz-transition:.5s;
    -webkit-transition:.5s;
    transition: .5s;
    background-color:#e64a41;
}
.fa-google-plus:hover {
    background-color:#e64a41;
}



</style>
</head>
<br><br><br>
<hr>
<footer class="s">

 <center>  <h4>The Rising People Welfare Society, DDA park (Woodland Park), Opposite Gate No.4 Pacific Mall, Subhash Nagar, New Delhi, India 110018 <a><BR>Email id:trpws2012@gmail.com</a></h4>
 <h4>Follow us on </h4></center>

<div class="footer-social-icons">
    <ul class="social-icons">
        <li><a href="https://www.facebook.com/TRPWS/" class="social-icon"> <i class="fa fa-facebook"></i></a></li>
        <li><a href="https://twitter.com/hashtag/trpws" class="social-icon"> <i class="fa fa-twitter"></i></a></li>
        <li><a href="https://www.instagram.com/trpws/" class="social-icon"> <i class="fa fa-instagram"></i></a></li>
        <li><a href="https://www.youtube.com/watch?v=IyX9jdKbGr0" class="social-icon"> <i class="fa fa-youtube"></i></a></li>
        <li><a href="https://in.linkedin.com/jobs/the-rising-people-welfare-society-jobs" class="social-icon"> <i class="fa fa-linkedin"></i></a></li>
        <li><a href="https://plus.google.com/+TheRisingPeopleWelfareSociety" class="social-icon"> <i class="fa fa-google-plus"></i></a></li>
    </ul>
</div>
</footer>
<html>